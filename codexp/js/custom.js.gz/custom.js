$(document).ready(function(){

    /* viewport checker */ 
    if ($(window).width() > 768) {
      $('.anim-block').viewportChecker({
          classToAdd: 'visible',
          classToRemove: 'invisible',
          offset: 300,
          invertBottomOffset: true,
          repeat: false,
          scrollHorizontal: false
      });
    } else {
      $('.anim-block').each( function() {
        $(this).removeClass('invisible');
      })
    }


      /* head load */
    setTimeout(function() {
      $('.block1-fluid').animate({opacity: 1}, 500);
    }, 500);

    setTimeout(function() {
      $('.navbar').animate({opacity: 1}, 500);
    }, 700);

    setTimeout(function() {
      $('.block1-fluid h1').animate({opacity: 1}, 500);
    }, 900);

    setTimeout(function() {
      $('.b1-btn-b').animate({opacity: 1}, 500);
    }, 1100);

    setTimeout(function() {
      $('.countdown-wrap, .block2-fluid').animate({opacity: 1}, 500);
    }, 1300);

    setTimeout(function() {
      $('.to-show-logo').animate({opacity: 1, marginTop:0}, 1000);
    }, 1300);

    setTimeout(function() {
      $('.motiv-appear').animate({opacity: 1, top:0}, 1000);
    }, 1400);

});


  /* COUNTDOWN */
  var countDownDate = new Date("Nov 12, 2017 20:25:20").getTime();

  var x = setInterval(function() {

    var now = new Date().getTime();

    var distance = countDownDate - now;

    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

    document.getElementById("c-days").innerHTML = days;
    document.getElementById("c-hours").innerHTML = hours;
    document.getElementById("c-minutes").innerHTML = minutes;
    document.getElementById("c-seconds").innerHTML = seconds;

    if (distance < 61) {
      clearInterval(x);
      document.getElementById("c-days").innerHTML = 0;
      document.getElementById("c-hours").innerHTML = 0;
      document.getElementById("c-minutes").innerHTML = 0;
      document.getElementById("c-seconds").innerHTML = 0;
    }
  }, 1000);
  /* COUNTDOWN END */ 

 

  /* ROTATE */
function rotate (event) {
  var x = event.clientX;
  var y = event.clientY;
  var w = window.innerWidth;
  var h = window.innerHeight;
  var midpoint = w / 2; 
  var midpoint2 = h / 2; 
  var pos = x - midpoint;
  var pos2 = y - midpoint2;
  var val = (pos / midpoint) * 10;
  var val2 = -(pos2 / midpoint2) * 10;
  var logo = document.getElementById("vue-image");
  var logo2 = document.getElementById("vue-image2");
  logo.style.transform = "perspective(550px) rotateY(" + val + "deg) rotateX(" + val2 + "deg)";
  logo2.style.transform = "perspective(550px) rotateY(" + val + "deg) rotateX(" + val2 + "deg)";
}

document.addEventListener("mousemove", function (event) {
  rotate (event)
}, false); 

  /* ROTATE END */

